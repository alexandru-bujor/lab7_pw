package product

import "MegaMobileBack/pkg/db"

func GetProductVariants(productID int) ([]Product, error) {
	var p Product
	if err := db.DB.First(&p, productID).Error; err != nil {
		return []Product{}, err
	}

	if p.AccountingType == "off_book" {
		return []Product{}, nil
	}

	if p.VariantGroupID == nil {
		return []Product{p}, nil
	}

	var variants []Product
	err := db.DB.
		Preload("Images").
		Where("(variant_group_id = ? OR id = ?) AND (accounting_type IS NULL OR accounting_type = '' OR accounting_type = 'on_book')",
			*p.VariantGroupID, *p.VariantGroupID).
		Find(&variants).Error

	return variants, err
}
