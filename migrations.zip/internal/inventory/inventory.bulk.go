package inventory

import (
	"MegaMobileBack/internal/product"
	"MegaMobileBack/pkg/db"
)

func SyncAllProductsToInventory(defaultSection string) (int, error) {
	if defaultSection == "" {
		defaultSection = "Apple SH"
	}

	var products []product.Product
	if err := db.DB.Preload("Variants").Find(&products).Error; err != nil {
		return 0, err
	}

	createdCount := 0
	for _, p := range products {
		if len(p.Variants) > 0 {
			for _, v := range p.Variants {
				var existingCount int64
				db.DB.Model(&InventoryItem{}).Where("product_id = ? AND variant_color = ? AND variant_storage = ? AND variant_ram = ?",
					p.ID, v.Color, v.Storage, v.RAM).Count(&existingCount)
				
				stock := v.Stock
				missing := stock - int(existingCount)
				
				for i := 0; i < missing; i++ {
					item := InventoryItem{
						ProductID:      p.ID,
						Section:        defaultSection,
						VariantColor:   v.Color,
						VariantStorage: v.Storage,
						VariantRAM:     v.RAM,
						BuyPrice:       v.Price,
						SellPrice:      v.Price,
						Status:         "in_stock",
					}
					if err := db.DB.Create(&item).Error; err != nil {
						continue
					}
					createdCount++
				}
			}
		} else {
			var existingCount int64
			db.DB.Model(&InventoryItem{}).Where("product_id = ?", p.ID).Count(&existingCount)
			
			stock := p.Stock
			missing := stock - int(existingCount)
			
			for i := 0; i < missing; i++ {
				item := InventoryItem{
					ProductID: p.ID,
					Section:   defaultSection,
					BuyPrice:  p.Price,
					SellPrice: p.Price,
					Status:    "in_stock",
				}
				if err := db.DB.Create(&item).Error; err != nil {
					continue
				}
				createdCount++
			}
		}
	}

	return createdCount, nil
}
