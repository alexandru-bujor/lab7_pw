package order

import (
	"MegaMobileBack/internal/client"
	"MegaMobileBack/internal/inventory"
	"MegaMobileBack/internal/product"
	"MegaMobileBack/pkg/db"
	"errors"
	"fmt"
	"strings"
	"time"

	"gorm.io/gorm"
)

type Service struct {
	DB *gorm.DB
}

func NewService() *Service { return &Service{DB: db.DB} }

func (s *Service) Create(order *Order) error {
	return s.DB.Create(order).Error
}

func (s *Service) List(status string, startDate string, endDate string) ([]Order, error) {
	var orders []Order
	q := s.DB.Model(&Order{})
	if status != "" {
		q = q.Where("status = ?", status)
	}
	if startDate != "" {
		q = q.Where("DATE(created_at) >= ?", startDate)
	}
	if endDate != "" {
		q = q.Where("DATE(created_at) <= ?", endDate)
	}
	if err := q.Order("created_at DESC").Find(&orders).Error; err != nil {
		return nil, err
	}
	return orders, nil
}

func (s *Service) GetByID(id int) (*Order, error) {
	var order Order
	if err := s.DB.First(&order, id).Error; err != nil {
		return nil, err
	}
	return &order, nil
}

func (s *Service) GetByClientID(clientID int) ([]Order, error) {
	var orders []Order
	if err := s.DB.Where("client_id = ?", clientID).Order("created_at DESC").Find(&orders).Error; err != nil {
		return nil, err
	}
	return orders, nil
}

func (s *Service) UpdateStatus(id int, status string) (*Order, error) {
	var order Order
	if err := s.DB.First(&order, id).Error; err != nil {
		return nil, err
	}

	order.Status = status
	if err := s.DB.Save(&order).Error; err != nil {
		return nil, err
	}

	return &order, nil
}

func (s *Service) CreateFromWebsite(input CreateOrderInput) (*Order, error) {
	if input.ClientEmail == "" {
		return nil, errors.New("client email is required")
	}
	if !strings.Contains(input.ClientEmail, "@") {
		return nil, errors.New("invalid email format")
	}

	clientSvc := client.NewService()
	clientSvc.DB = s.DB

	clientRecord, err := clientSvc.GetOrCreateClientByEmail(input.ClientEmail, input.ClientName, input.ClientPhone)
	if err != nil {
		return nil, err
	}

	order := &Order{
		ClientID:       &clientRecord.ID,
		ClientName:     input.ClientName,
		ClientEmail:    input.ClientEmail,
		ClientPhone:    input.ClientPhone,
		ProductID:      input.ProductID,
		ProductTitle:   input.ProductTitle,
		VariantColor:   input.VariantColor,
		VariantStorage: input.VariantStorage,
		VariantRAM:     input.VariantRAM,
		Quantity:       input.Quantity,
		SellPrice:      input.SellPrice,
		Status:         "pending",
		OrderSource:    input.OrderSource,
		AccountingType: input.AccountingType,
	}

	if order.OrderSource == "" {
		order.OrderSource = "website"
	}

	if order.AccountingType == "" {
		order.AccountingType = "on_book"
	}

	if err := s.DB.Create(order).Error; err != nil {
		return nil, err
	}

	return order, nil
}

func (s *Service) MarkAsSold(orderID int, inventoryItemID int, sellPrice *float64) (*Order, error) {
	var order Order
	if err := s.DB.First(&order, orderID).Error; err != nil {
		return nil, err
	}

	inventorySvc := inventory.NewService()
	inventorySvc.DB = s.DB

	var item inventory.InventoryItem
	if err := s.DB.First(&item, inventoryItemID).Error; err != nil {
		return nil, errors.New("inventory item not found")
	}

	if item.ProductID != order.ProductID {
		return nil, errors.New("inventory item does not match order product")
	}

	if item.Status == "sold" {
		return nil, errors.New("inventory item already sold")
	}

	var prod product.Product
	if err := s.DB.Preload("Variants").First(&prod, item.ProductID).Error; err != nil {
		return nil, err
	}

	now := time.Now()

	err := s.DB.Transaction(func(tx *gorm.DB) error {
		item.Status = "sold"
		item.SoldAt = &now
		if order.ClientID != nil {
			item.ClientID = order.ClientID
		}
		item.OrderID = &order.ID
		if sellPrice != nil {
			item.SellPrice = *sellPrice
		}
		if err := tx.Save(&item).Error; err != nil {
			return fmt.Errorf("failed to save inventory item: %w", err)
		}

		order.InventoryItemID = &item.ID
		order.BuyPrice = item.BuyPrice
		if sellPrice != nil {
			order.SellPrice = *sellPrice
		} else {
			order.SellPrice = item.SellPrice
		}
		order.Profit = order.SellPrice - order.BuyPrice
		order.Status = "completed"
		order.SoldAt = &now

		if err := tx.Save(&order).Error; err != nil {
			return fmt.Errorf("failed to save order: %w", err)
		}

		if order.ClientID != nil {
			var clientRecord client.Client
			if err := tx.First(&clientRecord, *order.ClientID).Error; err == nil {
				clientRecord.OrderCount++
				clientRecord.TotalSpent += order.SellPrice
				clientRecord.LastOrderDate = &now
				if err := tx.Save(&clientRecord).Error; err != nil {
					return fmt.Errorf("failed to update client record: %w", err)
				}
			}
		}

		hasVariant := item.VariantColor != "" || item.VariantStorage != "" || item.VariantRAM != ""
		if hasVariant {
			var variant product.ProductVariant
			err := tx.Where("product_id = ? AND color = ? AND storage = ? AND ram = ?",
				item.ProductID, item.VariantColor, item.VariantStorage, item.VariantRAM).
				First(&variant).Error
			if err == nil && variant.Stock > 0 {
				variant.Stock--
				if err := tx.Save(&variant).Error; err != nil {
					return fmt.Errorf("failed to decrement variant stock: %w", err)
				}
			}
		} else {
			if prod.Stock > 0 {
				prod.Stock--
				if err := tx.Model(&product.Product{}).Where("id = ?", prod.ID).Update("stock", prod.Stock).Error; err != nil {
					return fmt.Errorf("failed to decrement product stock: %w", err)
				}
			}
		}

		return nil
	})

	if err != nil {
		return nil, err
	}

	return &order, nil
}

func (s *Service) Delete(id int) error {
	return s.DB.Delete(&Order{}, id).Error
}

func (s *Service) GetSecondaryOrders() ([]Order, error) {
	var orders []Order
	if err := s.DB.Where("is_visible_in_secondary = ?", true).Order("created_at DESC").Find(&orders).Error; err != nil {
		return nil, err
	}
	return orders, nil
}
