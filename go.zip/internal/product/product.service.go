package product

import (
	"MegaMobileBack/pkg/db"

	"gorm.io/gorm"
)

func GetAllProducts() ([]Product, error) {
	var products []Product
	err := db.DB.
		Preload("Images").
		Preload("Variants").
		Find(&products).Error

	return products, err
}

func AddProduct(p *Product) error {
	var existingProducts []Product
	db.DB.Where("title = ? AND category_id = ?", p.Title, p.CategoryID).Find(&existingProducts)

	if len(existingProducts) > 0 {
		if existingProducts[0].VariantGroupID != nil {
			p.VariantGroupID = existingProducts[0].VariantGroupID
		} else {
			groupID := existingProducts[0].ID
			p.VariantGroupID = &groupID
			db.DB.Model(&existingProducts[0]).Update("variant_group_id", groupID)
		}
	}

	if len(p.Images) > 0 {
		seen := map[string]bool{}
		dedup := make([]ProductImage, 0, len(p.Images))
		for _, img := range p.Images {
			if img.URL == "" {
				continue
			}
			if seen[img.URL] {
				continue
			}
			seen[img.URL] = true
			dedup = append(dedup, img)
		}
		p.Images = dedup
	}

	err := db.DB.Create(p).Error
	if err != nil {
		return err
	}

	if p.VariantGroupID == nil {
		p.VariantGroupID = &p.ID
		db.DB.Model(p).Update("variant_group_id", p.ID)
	}

	p.Slug = GenerateSlug(p.Title, p.ID)
	return db.DB.Model(p).Update("slug", p.Slug).Error
}

func DeleteProduct(id int) error {
	tx := db.DB.Begin()

	if err := tx.Where("product_id = ?", id).Delete(&ProductImage{}).Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Where("product_id = ?", id).Delete(&ProductVariant{}).Error; err != nil {
		tx.Rollback()
		return err
	}

	if err := tx.Delete(&Product{}, id).Error; err != nil {
		tx.Rollback()
		return err
	}

	return tx.Commit().Error
}

func UpdateProduct(id int, p *Product) error {
	p.ID = id

	var existingProduct Product
	if err := db.DB.First(&existingProduct, id).Error; err == nil {
		if existingProduct.Title != p.Title {
			p.Slug = GenerateSlug(p.Title, p.ID)
		}
	}
	return db.DB.Transaction(func(tx *gorm.DB) error {
		if err := tx.Session(&gorm.Session{FullSaveAssociations: false}).Save(p).Error; err != nil {
			return err
		}

		if err := tx.Where("product_id = ?", p.ID).Delete(&ProductImage{}).Error; err != nil {
			return err
		}

		seen := map[string]bool{}
		var toInsert []ProductImage
		for _, img := range p.Images {
			if img.URL == "" {
				continue
			}
			if seen[img.URL] {
				continue
			}
			seen[img.URL] = true
			toInsert = append(toInsert, ProductImage{
				ProductID: p.ID,
				URL:       img.URL,
				AltText:   img.AltText,
				IsMain:    img.IsMain,
			})
		}

		if len(toInsert) > 0 {
			if err := tx.Create(&toInsert).Error; err != nil {
				return err
			}
		}

		if p.Variants != nil {
			if err := tx.Where("product_id = ?", p.ID).Delete(&ProductVariant{}).Error; err != nil {
				return err
			}
			if len(p.Variants) > 0 {
				var variantsToInsert []ProductVariant
				for _, v := range p.Variants {
					variantsToInsert = append(variantsToInsert, ProductVariant{
						ProductID: p.ID,
						Storage:   v.Storage,
						RAM:       v.RAM,
						Color:     v.Color,
						Price:     v.Price,
					})
				}
				if err := tx.Create(&variantsToInsert).Error; err != nil {
					return err
				}
			}
		}

		return nil
	})
}
